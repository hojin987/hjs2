package sample.less03.service;

public interface SampleService {

	public Integer doAdd(String str1, String str2) throws Exception ;
	
	public Integer doAdd(Integer str1, Integer str2) throws Exception ;
}
